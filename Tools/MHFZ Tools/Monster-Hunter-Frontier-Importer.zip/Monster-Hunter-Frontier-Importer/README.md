# Monster-Hunter-Frontier-Importer
A model importer for Monster Hunter Frontier FMod Files

# Author
* **AsteriskAmpersand/\*&**

# Acknowledgements
* **MHVuze** - For the Frontier Recursive Block Format documentation used to build this importer.
* **Silvris** - For the Materials and Skeleton documentation used to build this importer.