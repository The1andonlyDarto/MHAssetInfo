# -*- coding: utf-8 -*-
"""
Created on Mon Dec 30 01:17:01 2019

@author: AsteriskAmpersand
"""

from ..fmod.FSkl import FSkeleton
import bpy
import bmesh
import array
import os
from math import radians
from mathutils import Vector, Matrix, Euler
from pathlib import Path

class FSklImporter():   
    @staticmethod
    def execute(fmodPath, is_amh):
        skeleton = FSkeleton(fmodPath, is_amh).skeletonStructure()
        currentSkeleton = {}
        odata = bpy.data.armatures.new("root")
        o = bpy.data.objects.new("Armature", odata)
        bpy.context.scene.objects.link(o)
        bpy.context.scene.objects.active = o
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
        editBones = o.data.edit_bones
        #bpy.context.scene.update()
        currentSkeleton = {"Armature":o}
        for bone in skeleton.values():
            FSklImporter.importBone(bone, currentSkeleton, skeleton, editBones)
        bpy.ops.object.mode_set(mode='POSE')
    @staticmethod
    def deserializePoseVector(vec4):
        m = Matrix.Identity(4)
        for i in range(4):
            m[i][3]=vec4[i]
        return m

    @staticmethod
    def importBone(bone, skeleton, skeletonStructure, editbones):
        ix = bone.nodeID
        print("bone %d"%ix)
        print(bone.posVec)
        if "Bone.%03d"%ix in skeleton:
            return
        #o = bpy.data.objects.new("Bone.%03d"%ix, None)
        #skeleton["Bone.%03d"%ix]=o
        #bpy.context.scene.objects.link( o )
        parentName = "Armature" if bone.parentID==-1 else "Bone.%03d"%bone.parentID
        #if parentName not in skeleton:
            #FSklImporter.importBone(skeletonStructure[bone.parentID],skeleton,skeletonStructure)
        #o["id"] = bone.nodeID
        #o.parent = skeleton[parentName]
        zero = [0.0, 0.0, 0.0, 1.0]
        #if bone.posVec == zero or parentName == "Armature":
        if parentName == "Armature":
            print("zerobone")
            bdata = editbones.new("Bone.%03d"%ix)
            bdata.head = (0, 1, 0)
            bdata.tail = (0, 0, 0)
            #check its children
            #if bone.leftChild != -1:
                #childID = bone.leftChild
                #while childID != -1:
                    #if skeletonStructure[childID].posVec == bone.posVec:
                        #check siblings
                        #childID = skeletonStructure[childID].rightSibling
                    #else:
                        #add the bone!
                        #bdata = editbones.new("Bone.%03d"%ix)
                        #bdata.head = (0, 0, 0)
                        #bdata.tail = (0, 0, 1)
                        #break
        else:
            print("nonzero bone")
            #print(bone.vec1)
            #print(bone.vec2)
            #print(Euler((radians(bone.vec2[0]), radians(bone.vec2[1]), radians(bone.vec2[2]))))
            bdata = editbones.new("Bone.%03d"%ix)
            bdata.use_inherit_scale = False
            #bdata.head = (skeletonStructure[bone.parentID].posVec[0], skeletonStructure[bone.parentID].posVec[1], skeletonStructure[bone.parentID].posVec[2])
            bdata.head = (0, 0, 0)
            bdata.tail = (0, 1, 0)
            rx = Matrix.Rotation(radians(bone.vec2[0]), 4, 'X')
            ry = Matrix.Rotation(radians(bone.vec2[1]), 4, 'Y')
            rz = Matrix.Rotation(radians(bone.vec2[2]), 4, 'Z')
            mat = Euler((radians(bone.vec2[0]), radians(bone.vec2[1]), radians(bone.vec2[2]))).to_matrix()
            bdata.matrix = mat.to_4x4()
            bdata.head = (bdata.head[0] + editbones[parentName].head[0]+bone.posVec[0], bdata.head[1] + editbones[parentName].head[1]+bone.posVec[1],bdata.head[2] + editbones[parentName].head[2]+bone.posVec[2])
            bdata.tail = (bdata.tail[0] + editbones[parentName].head[0]+bone.posVec[0], bdata.tail[1] + editbones[parentName].head[1]+bone.posVec[1],bdata.tail[2] + editbones[parentName].head[2]+bone.posVec[2])
            #bdata.tail = (editbones[parentName].tail[0]+bone.posVec[0], editbones[parentName].tail[1]+bone.posVec[1], editbones[parentName].tail[2]+bone.posVec[2])
            #if parentName != "Bone.000":
        if parentName != "Armature":
            bdata.parent = editbones[parentName]
        #odata = bpy.data.bones.new("Bone.%03d"%ix)
        #o.matrix_local = FSklImporter.deserializePoseVector(bone.posVec)
        #o.show_wire = True
        #o.show_x_ray = True
        #o.show_bounds = True