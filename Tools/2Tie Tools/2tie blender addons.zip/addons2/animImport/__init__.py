
bl_info = {
	"name": "Outbreak/Monster Hunter animation importer",
	"category": "Animation",
	"author": "2Tie",
	"location": "Armature > Data",
	"version": (1,0,0)
}

import bpy
import struct
import mathutils
from math import pi
from bpy_extras.io_utils import ImportHelper

class animImporter():
	def readInt(f):
		return int.from_bytes(f.read(4), "little")
	def readShort(f):
		return int.from_bytes(f.read(2), "little", signed = True)
	def readFloat(f):
		[val] = struct.unpack('<f', f.read(4))
		return val

	def execute(path, anim, targetflag, firsttable, sub, true):
		print("clearing old animation..")
		bpy.data.objects['Armature'].animation_data_clear() #this loads a blank action, actually!
		print("resetting pose")
		bpy.context.scene.frame_set(0)
		for pb in bpy.data.objects['Armature'].pose.bones:
			bpy.context.object.data.bones.active = pb.bone
			pb.bone.select = True
			pb.rotation_mode = 'XYZ'
			pb.rotation_euler = (0, 0, 0)
			pb.location = (0, 0, 0)
			pb.scale = (1, 1, 1)
		print("importing!")
		#scale = 23.5/0xFFFF #degrees range from 0-360, this ranges from 0-FFFF; currently a guesstimated number
		scale = pi/0x2000
		armName = 'Armature'
		with open(path, "rb") as f:
			tablePointers = []
			tableSizes = []
			subtablePointers = []
			subtableSizes = []
			while True:
				temp = animImporter.readInt(f)
				temp2 = animImporter.readInt(f)
				if temp != 0:
					tablePointers.append(temp2)
					tableSizes.append(temp)
					if not firsttable:
						temp = animImporter.readInt(f)
						temp2 = animImporter.readInt(f)
						if temp != 0:
							subtablePointers.append(temp2)
							subtableSizes.append(temp)
				else:
					break
			#we now have our main tables
			if sub:
				tablePointers = subtablePointers
				tableSizes = subtableSizes
			print("Total number of tables: %d"%len(tablePointers))
			animation = -1
			valid = 0
			totalbone = 0
			bpy.ops.object.mode_set(mode='POSE')
			#set up the action
			#action = bpy.data.actions.new("Anim")
			#now parse the animation pointers
			for t in range(len(tablePointers)):
				f.seek(tablePointers[t])
				animPointers = []
				for i in range(tableSizes[t]):
					animPointers.append(animImporter.readInt(f))
					
				print("number of animations in table: %d"%len(animPointers))
				#find the first valid pointer
				print("Selected anim " + str(anim))
				if true:
					animation = anim
				else:
					if t == 0:
						for i in range(len(animPointers)):
							if animPointers[i] != 0xFFFFFFFF:
								#found valid!
								if valid == anim:
									animation = i
									break
								else:
									valid+=1
				if animation == -1:
					print("whoops, outside normal bound")
					return
				print("Reading anim " + str(animation))
				if t > 1 and firsttable:
					armName = 'Armature.%03d'%int(t/2)
					#bpy.ops.object.select_all(action='DESELECT')
					#bpy.data.objects[armName].select = True #avoid console errors
				#now start parsing an animation!
				if(animPointers[animation] == 0xFFFFFFFF):
					print("missing data, trying again with next limb")
					continue
				f.seek(animPointers[animation])
				while True:
					temp = animImporter.readInt(f)
					if temp & 0x80000000 != 0:
						children = animImporter.readInt(f)
						size = animImporter.readInt(f)
						#print("container entered at " + hex(f.tell()-0xC))
						#if temp & 0x7FFFFFFF == 1:
							#hitboxes?
							#read
							#for now, let's skip this
							#print("found hitboxes, oops")
							#f.read(size - 0xC)
							#continue
						#elif temp & 0x7FFFFFFF == 2:
							#bone keyframes
						#print("found keyframes!")
						#read a data entry?
						animImporter.readInt(f)
						looppt = animImporter.readFloat(f) #loop point
						#print("loop start frame: " + str(looppt))
						#now we're at the bone containers
						for b in range(children):
							#print("checking bone " + str(b))
							boneflags = animImporter.readInt(f)
							bonechildren = animImporter.readInt(f)
							bonesize = animImporter.readInt(f)
							if bonechildren == 0:
								#print("no kids")
								continue
							#bone has data!
							if boneflags & targetflag != 0:
								#find the datum with the flag
								#print("has the flag")
								boneName = "Bone.%03d"%(b+totalbone)
								for c in range(bonechildren):
									entryflag = animImporter.readInt(f)
									entryframes = animImporter.readInt(f)
									entrysize = animImporter.readInt(f)
									func = animImporter.readInt
									if entryflag & 0x80120000 == 0x80120000:
										func = animImporter.readShort
										scale = pi/0x2000
									elif entryflag & 0x80220000 == 0x80220000:
										func = animImporter.readFloat
										scale = 1
									else:
										print("skipped frames of type ", hex(entryflag))
										f.read(entrysize - 0xC)
										continue
									#we're at the datum
									for frame in range(entryframes):
										fval = func(f)
										frame = func(f)
										rint = func(f)
										lint = func(f)
										#lint and rint have to do with the hermite interpolation
										#print("bone " + str(b+totalbone) + " frame: " + str(frame) + ", " + str(fval) + " " + str(lint) + " " + str(rint))
										
										#now make a keyframe for this?
										bpy.context.scene.frame_set(frame)
										ob = bpy.data.objects[armName].data.bones[boneName]
										pb = bpy.data.objects[armName].pose.bones[boneName]
										bpy.context.object.data.bones.active = pb.bone
										pb.bone.select = True
										if entryflag & 0x8 == 0x8:
											pb.rotation_euler.x = fval*scale
											pb.keyframe_insert(data_path="rotation_euler", index = 0)
										elif entryflag & 0x10 == 0x10:
											pb.rotation_euler.y = fval*scale
											pb.keyframe_insert(data_path="rotation_euler", index = 1)
										elif entryflag & 0x20 == 0x20:
											pb.rotation_euler.z = fval*scale
											pb.keyframe_insert(data_path="rotation_euler", index = 2)
										elif entryflag & 0x40 == 0x40:
											pb.location.x = fval/15
											pb.keyframe_insert(data_path="location", index = 0)
										elif entryflag & 0x80 == 0x80:
											pb.location.y = fval/15
											pb.keyframe_insert(data_path="location", index = 1)
										elif entryflag & 0x100 == 0x100:
											pb.location.z = fval/15
											pb.keyframe_insert(data_path="location", index = 2)
										elif entryflag & 0x1 == 0x1:
											pb.scale.x = fval/15
											pb.keyframe_insert(data_path="scale", index = 0)
											ob.use_inherit_scale = False
											ob.keyframe_insert(data_path="use_inherit_scale")
										elif entryflag & 0x2 == 0x2:
											pb.scale.y = fval/15
											pb.keyframe_insert(data_path="scale", index = 1)
											ob.use_inherit_scale = False
											ob.keyframe_insert(data_path="use_inherit_scale")
										elif entryflag & 0x4 == 0x4:
											pb.scale.z = fval/15
											pb.keyframe_insert(data_path="scale", index = 2)
											ob.use_inherit_scale = False
											ob.keyframe_insert(data_path="use_inherit_scale")
										else:
											print("bone transform of type " + hex(entryflag))
							else:
								#next!
								#print("lacking in flaggage")
								f.read(bonesize - 0xC)
						#done with the bone containers for the animation!
						#time to wrap it up for now
						totalbone += children
						if firsttable and t%2 == 1:
							totalbone = 0
						break
					else:
						animImporter.readInt(f) #read the other data field and continue
				#if firsttable:
				#	break
		print("done parsing!")
		bpy.context.scene.frame_start = 0
		bpy.context.scene.frame_end = bpy.context.scene.frame_current
		actionName = "Main/"
		if sub:
			actionName = "Sub/"
		bpy.data.objects['Armature'].animation_data.action.name = actionName+'%02d'%anim
            

class OPR_OT_animImport(bpy.types.Operator, ImportHelper):
	bl_idname = 'opr.animimport'
	bl_label = 'Import Animation'
	bl_options = {'REGISTER', 'UNDO'}
 
	# ImportHelper mixin class uses this
	filename_ext = "_tbl.bin"
	filter_glob = bpy.props.StringProperty(default="*_tbl.bin", options={'HIDDEN'}, maxlen=255)
	
	anim_num = bpy.props.IntProperty(
		name = "Animation Number",
		description = "which animation to import",
		default = 0)
		
	target_flag = bpy.props.IntProperty(
		name = "animation flags",
		description = "which flags (in hex) to import",
		default = 0xFFF)
		
	#first_table = bpy.props.BoolProperty(
	#	name = "player animation",
	#	description = "wip for player animations",
	#	default = False)
		
	sub = bpy.props.BoolProperty(
		name = "use subtable (monster-unique)",
		description = "testou",
		default = False)
		
	true = bpy.props.BoolProperty(
		name = "use true index",
		description = "use if you already know anim IDs",
		default = False)
		
	def execute(self, context):
		animImporter.execute(self.properties.filepath, self.anim_num, self.target_flag, False, self.sub, self.true)
		return {'FINISHED'}

class HelloWorldPanel(bpy.types.Panel):
	"""Creates a Panel in the Object properties window"""
	bl_label = "Hello World Panel"
	bl_idname = "OBJECT_PT_mh"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_context = "armature_edit"

	def draw(self, context):
		layout = self.layout
		obj = context.object
		column = layout.column()
		column.operator("opr.animimport")

def register():
	bpy.utils.register_class(HelloWorldPanel)
	bpy.utils.register_class(OPR_OT_animImport)

def unregister():
	bpy.utils.unregister_class(HelloWorldPanel)
	bpy.utils.unregister_class(OPR_OT_animImport)

if __name__ == "__main__":
	try:
		unregister()
	except:
		pass
	register()
