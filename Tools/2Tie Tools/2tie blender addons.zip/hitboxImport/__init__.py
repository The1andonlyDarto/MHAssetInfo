
bl_info = {
	"name": "Monster Hunter Hitboxes Importer",
	"category": "Import-Export",
	"author": "2Tie",
	"location": "File > Import-Export > MHHitboxes",
	"version": (1,0,0)
}

import bpy
import struct
import math
import mathutils
from bpy_extras.io_utils import ImportHelper

class hitboxImporter():
	def readInt(f):
		return int.from_bytes(f.read(4), "little")
	def readShort(f):
		return int.from_bytes(f.read(2), "little", signed = True)
	def readFloat(f):
		[val] = struct.unpack('<f', f.read(4))
		return val
		
	def execute(path, bodygroup):
		#open the file, start reading the data!
		with open(path, "rb") as f:
			bs = bpy.context.scene.objects['Armature'].data.bones
			cols = [(1,1,1),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(0,0,0)]
			for i in range(8):
				mat = bpy.data.materials.new("hitbox.%03d"%i)
				mat.use_nodes = False
				mat.diffuse_color = cols[i]
			bpy.ops.object.mode_set(mode='OBJECT')
			num = -1
			tot = -1
			while True:
				tot += 1
				bone = hitboxImporter.readShort(f)
				cap = hitboxImporter.readShort(f)
				sub = hitboxImporter.readShort(f)
				bg = hitboxImporter.readShort(f)
				unkf = hitboxImporter.readFloat(f)
				rad = hitboxImporter.readFloat(f)
				x1 = hitboxImporter.readFloat(f)
				y1 = hitboxImporter.readFloat(f)
				z1 = hitboxImporter.readFloat(f)
				x2 = hitboxImporter.readFloat(f)
				y2 = hitboxImporter.readFloat(f)
				z2 = hitboxImporter.readFloat(f)
				if bone == -1 and cap == -1:
					break
				if bone == 125:
					print("HEY! cap " + str(tot) + " had bone 0x7D")
					print("next hitbox is severable!")
					continue
				num += 1
				bparent = bs["Bone.%03d"%bone].head_local
				bpy.ops.mesh.primitive_uv_sphere_add(segments=10, ring_count=11, size=rad) #creates the sphere
				#now stretch it to the correct length?
				#calc the distance between endpoints...
				hb = bpy.context.active_object
				if cap == 1:
					len = math.sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)
					#stretch the top
					for v in hb.data.vertices:
						#print(v.co)
						if v.co[2] > 0:
							v.co[2] += len
					#now place the "bottom" node at coord1
				hb.location = (x1, y1, z1)
				#print(str(num) + " parent: " + str(bone) + " total: "  + str(tot))
				#print(bparent)
				#print(str(x1) + " " + str(y1) + " " + str(z1))
				#and rotate to place the "top" node at coord2
				if cap == 1:
					rot = mathutils.Vector((x2-x1,y2-y1,z2-z1)).to_track_quat('Z', 'Y')
					#rot = (x2-x1,y2-y1,z2-z1).to_translation().to_track_quat('Z', 'Y')
					hb.rotation_mode = 'QUATERNION'
					hb.rotation_quaternion = rot
					#print(rot)
				if sub > 7:
					print("oopsie, sub was " + str(sub))
				mat = sub
				if bodygroup:
					mat = bg
				hb.active_material = bpy.data.materials.get("hitbox.%03d"%mat)
				hb.parent = bpy.context.scene.objects['Armature']
				hb.parent_bone = ("Bone.%03d"%bone)
				hb.parent_type = 'BONE'
		
		
		
		
		
		

class importHitboxes(bpy.types.Operator, ImportHelper):
	bl_idname = 'opr.hitboximport'
	bl_label = 'Import Hitboxes'
	bl_options = {'REGISTER', 'UNDO'}
	
	# ImportHelper mixin class uses this
	filename_ext = ".hbx"
	filter_glob = bpy.props.StringProperty(default="*.hbx", options={'HIDDEN'}, maxlen=255)
	
	bodygroup = bpy.props.BoolProperty(
		name = "colour bodygroups instead of meatzones",
		description = "what it says on the tin",
		default = False)
	
	def execute(self, context):
		hitboxImporter.execute(self.properties.filepath, self.bodygroup)
		return {'FINISHED'}

def menu_func_import(self, context):
	self.layout.operator(importHitboxes.bl_idname, text="MH Hitboxes (.hbx)")
	
def register():
	bpy.utils.register_class(importHitboxes)
	bpy.types.INFO_MT_file_import.append(menu_func_import)
	
def unregister():
	bpy.utils.unregister_class(importHitboxes)
	bpy.types.INFO_MT_file_import.remove(menu_func_import)

